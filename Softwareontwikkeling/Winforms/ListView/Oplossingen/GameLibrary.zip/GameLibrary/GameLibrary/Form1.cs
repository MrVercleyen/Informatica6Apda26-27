﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameLibrary
{
    public partial class Form1 : Form
    {
        private List<Game> games;
        public Form1()
        {
            games = new List<Game>();

            games.Add(new Game("GTA6", "PS5", "Actie", 2026));
            games.Add(new Game("RDR2", "PC", "Actie", 2018));
            InitializeComponent();

            Games_ListView.View = View.Details;
            Games_ListView.Columns.Add("Naam");
            Games_ListView.Columns.Add("Platform");
            Games_ListView.Columns.Add("Genre");
            Games_ListView.Columns.Add("Jaar");
            Render_Listview();
        }

        private void Render_Listview()
        {
            Games_ListView.Items.Clear();
            foreach (var game in games)
            {
                Games_ListView.Items.Add(new ListViewItem(new[] { game.Name, game.Platform, game.Genre, game.Year.ToString() }));
            }
        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
            Game newgame = new Game(this.Name_Textbox.Text, this.Platform_Textbox.Text, this.Genre_Textbox.Text, int.Parse(this.Year_Textbox.Text));

            games.Add(newgame);
            Render_Listview();

        }

        private void Remove_Button_Click(object sender, EventArgs e)
        {
            if (this.Games_ListView.SelectedIndices.Count > 0)
            {
                int index = this.Games_ListView.SelectedIndices[0];

                games.RemoveAt(index);
                Render_Listview();
            }
        }
    }
}
