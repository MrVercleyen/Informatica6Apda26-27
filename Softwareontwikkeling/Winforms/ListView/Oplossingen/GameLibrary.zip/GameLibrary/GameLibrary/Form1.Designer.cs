﻿namespace GameLibrary
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label Name_Label;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            this.Games_ListView = new System.Windows.Forms.ListView();
            this.Add_Button = new System.Windows.Forms.Button();
            this.Name_Textbox = new System.Windows.Forms.TextBox();
            this.Platform_Textbox = new System.Windows.Forms.TextBox();
            this.Genre_Textbox = new System.Windows.Forms.TextBox();
            this.Year_Textbox = new System.Windows.Forms.TextBox();
            this.Remove_Button = new System.Windows.Forms.Button();
            Name_Label = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Games_ListView
            // 
            this.Games_ListView.HideSelection = false;
            this.Games_ListView.Location = new System.Drawing.Point(72, 48);
            this.Games_ListView.Name = "Games_ListView";
            this.Games_ListView.Size = new System.Drawing.Size(322, 338);
            this.Games_ListView.TabIndex = 0;
            this.Games_ListView.UseCompatibleStateImageBehavior = false;
            // 
            // Add_Button
            // 
            this.Add_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Button.Location = new System.Drawing.Point(422, 295);
            this.Add_Button.Name = "Add_Button";
            this.Add_Button.Size = new System.Drawing.Size(250, 67);
            this.Add_Button.TabIndex = 1;
            this.Add_Button.Text = "Voeg Toe";
            this.Add_Button.UseVisualStyleBackColor = true;
            this.Add_Button.Click += new System.EventHandler(this.Add_Button_Click);
            // 
            // Name_Textbox
            // 
            this.Name_Textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_Textbox.Location = new System.Drawing.Point(614, 65);
            this.Name_Textbox.Name = "Name_Textbox";
            this.Name_Textbox.Size = new System.Drawing.Size(125, 38);
            this.Name_Textbox.TabIndex = 2;
            // 
            // Platform_Textbox
            // 
            this.Platform_Textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Platform_Textbox.Location = new System.Drawing.Point(614, 119);
            this.Platform_Textbox.Name = "Platform_Textbox";
            this.Platform_Textbox.Size = new System.Drawing.Size(125, 38);
            this.Platform_Textbox.TabIndex = 3;
            // 
            // Genre_Textbox
            // 
            this.Genre_Textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genre_Textbox.Location = new System.Drawing.Point(614, 179);
            this.Genre_Textbox.Name = "Genre_Textbox";
            this.Genre_Textbox.Size = new System.Drawing.Size(125, 38);
            this.Genre_Textbox.TabIndex = 4;
            // 
            // Year_Textbox
            // 
            this.Year_Textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Year_Textbox.Location = new System.Drawing.Point(614, 241);
            this.Year_Textbox.Name = "Year_Textbox";
            this.Year_Textbox.Size = new System.Drawing.Size(125, 38);
            this.Year_Textbox.TabIndex = 5;
            // 
            // Name_Label
            // 
            Name_Label.AutoSize = true;
            Name_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Name_Label.Location = new System.Drawing.Point(477, 68);
            Name_Label.Name = "Name_Label";
            Name_Label.Size = new System.Drawing.Size(86, 31);
            Name_Label.TabIndex = 6;
            Name_Label.Text = "Naam";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.Location = new System.Drawing.Point(477, 122);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(144, 39);
            label1.TabIndex = 7;
            label1.Text = "Platform";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.Location = new System.Drawing.Point(477, 179);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(111, 39);
            label2.TabIndex = 8;
            label2.Text = "Genre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.Location = new System.Drawing.Point(477, 241);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(84, 39);
            label3.TabIndex = 9;
            label3.Text = "Jaar";
            // 
            // Remove_Button
            // 
            this.Remove_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remove_Button.Location = new System.Drawing.Point(422, 371);
            this.Remove_Button.Name = "Remove_Button";
            this.Remove_Button.Size = new System.Drawing.Size(250, 67);
            this.Remove_Button.TabIndex = 10;
            this.Remove_Button.Text = "Verwijder";
            this.Remove_Button.UseVisualStyleBackColor = true;
            this.Remove_Button.Click += new System.EventHandler(this.Remove_Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Remove_Button);
            this.Controls.Add(label3);
            this.Controls.Add(label2);
            this.Controls.Add(label1);
            this.Controls.Add(Name_Label);
            this.Controls.Add(this.Year_Textbox);
            this.Controls.Add(this.Genre_Textbox);
            this.Controls.Add(this.Platform_Textbox);
            this.Controls.Add(this.Name_Textbox);
            this.Controls.Add(this.Add_Button);
            this.Controls.Add(this.Games_ListView);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView Games_ListView;
        private System.Windows.Forms.Button Add_Button;
        private System.Windows.Forms.TextBox Name_Textbox;
        private System.Windows.Forms.TextBox Platform_Textbox;
        private System.Windows.Forms.TextBox Genre_Textbox;
        private System.Windows.Forms.TextBox Year_Textbox;
        private System.Windows.Forms.Button Remove_Button;
    }
}

