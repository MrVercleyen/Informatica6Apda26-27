﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary
{
    internal class Game
    {
        public string Name { get; set; }
        public string Platform { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }

        public Game(string name, string platform, string genre, int year)
        {
            Name = name;
            Platform = platform;
            Genre = genre;
            Year = year;
        }
    }
}
